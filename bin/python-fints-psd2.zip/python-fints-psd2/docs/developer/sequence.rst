FinTS Segment Sequence
----------------------

A message is a sequence of segments. The :class:`~fints.formals.SegmentSequence` object allows searching for segments by type and version, by default recursing into nested sequences.

.. autoclass:: fints.types.SegmentSequence
   :members:
   :undoc-members: print_nested

