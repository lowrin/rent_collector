Developer documentation/API
===========================

This part of the documentation is for you if you want to improve python-fints, but also if you just want to look behind the curtain.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   parsing
   segments/index
   sequence
   working
   types
